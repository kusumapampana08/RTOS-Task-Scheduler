
from time import sleep

class Task:
    def __init__(self,name,priority,state='READY'):
        self.name=name
        self.priority=priority
        self.state=state

tasks=[
    Task('Sensor Monitoring',1),
    Task('Motor Control',2),
    Task('Display Update',3),
    Task('UART Communication',4)
]

tasks.sort(key=lambda x:x.priority)

print("RTOS Priority Scheduler Simulation")
print("-"*40)

for task in tasks:
    task.state='RUNNING'
    print(f"Running: {task.name}")
    sleep(1)
    task.state='COMPLETED'
    print(f"Completed: {task.name}")

print("\nAll tasks executed successfully.")
